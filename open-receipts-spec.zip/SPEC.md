# Open Receipts v0.1 — Spec (2 pages)

## 1) Purpose
Portable, content-minimal proof that an event occurred. Each receipt is a tiny JSON object, **Ed25519-signed** over a **JCS** (JSON Canonicalization Scheme) byte string. **Revocation is also a receipt.**

## 2) Fields
```
rid            string   (unique id)
when           string   (ISO8601, UTC)
issuer         string   (DID, e.g., did:web:example.com)
where          object   { host, coarse }
what           object   { badge, kind [, revoke_of] }
flags          array    [optional]
metrics        object   [optional] – simple numerics
basis          string   [optional] – e.g., prior rid / digest
kid            string   key id for rotation (issuer’s namespace)
schema         string   spec version (e.g., "0.1")
sig            string   hex Ed25519 signature over canonical JSON without `sig`
```

**Badges**  
- `green` – routine/confirmed  
- `amber` – uncertain/experimental (may route to eval)  
- `gold` – promoted/approved  
*(revocations typically use `amber` with `revoke_of`)*

## 3) Canonicalization & Signature
- Canonicalize with **JCS**: sort keys (recursively), `UTF-8`, no whitespace variation.
- Sign **canonical bytes** using **Ed25519** with the issuer’s key (`kid`).
- `sig` is added **after** signing, as lowercase hex.

## 4) Revocation
Revoke by emitting a new receipt from same issuer:
```
what.badge = "amber"
what.kind  = "revocation"
what.revoke_of = <rid of prior receipt>
```
Consumers treat the original as **inactive** from the revocation’s `when` forward.

## 5) Interop Notes
- **CloudEvents mapping**: `rid→id`, `issuer→source`, `what.kind→type`, `when→time`, `basis→subject`
- **OpenTelemetry**: attach fields as span attributes under `receipts.*`
- **VC wrapper (optional)**: embed receipt JSON in a VC `credentialSubject` for ecosystems that require VC plumbing.

## 6) Security & Privacy
- Keep payloads content-minimal (no PII, prompts, or transcripts).
- Rotate keys (`kid`) and publish public keys via an issuer-controlled page or registry entry.
- Offline verify must succeed with just `{receipt, public key}`.

## 7) Compliance
An implementation is “Open Receipts v0.1 Verified” if it passes the **test vectors**.
